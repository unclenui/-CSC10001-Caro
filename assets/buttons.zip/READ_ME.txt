Thank you for Purchasing my SCI-FI BUTTONS+ asset pack!

License:
 - Assets can be edited.
 - Assets CAN'T be Redistributed or Resold, even if edited.
 - Assets can be used for non-commercial and Commercial projects. (if you paid at least $0.25)

You can follow the updates/creation of further packs on Instagram: @catter.pxl.

Leave a Rating and Comment if u liked this Project.